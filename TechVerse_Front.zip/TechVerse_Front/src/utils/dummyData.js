// import img1 from '../assets/Hero_Homepage_Accessories_Family_Q4FY22_VP2-859x540.avif'
// import img2 from '../assets/microsoft-surface-500x500.webp'
// import img3 from '../assets/c43c33fbadc434d69e14ce0ea87066dd.jpg'
// import img4 from '../assets/four.jpg'
// import img5 from '../assets/five.webp'
// import img6 from '../assets/download_4__1_3.jpg.jpeg'
import img7 from '../assets/airdot.webp'



export let productList  = [];
export let productListGamingPc = [];
export let productListLaptops = [];
export let productListPcParts = [];
export let productListPeripherals = [];


// fetch('http://localhost:3000/products/')
//   .then(response => response.json())
//   .then(data => {
//     productList.push(...data.map(product => ({ ...product, key: product._id })));


//     console.log(productList);

    


//     productListGamingPc = data.filter(product => product.category === 'Gaming PC');
//     productListLaptops = data.filter(product => product.category === 'Laptops');
//     productListPcParts = data.filter(product => product.category === 'PC Parts');
//     productListPeripherals = data.filter(product => product.category === 'Peripherals');

//   });
  