import * as React from 'react';
import { Box, IconButton, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tooltip } from '@mui/material';
import {ViewCozyTwoTone,AspectRatio, CancelPresentation} from "@mui/icons-material";
import ConfirmationDialog from './ConfirmationDialog';
import { ErrorToaster, SuccessToaster } from './Toaster';
import { useState } from 'react';
import PdfDocument from './PdfDocument';



const Orders = () => {
  const user = localStorage.getItem('accountNumber');
  const role = localStorage.getItem('role');
  const [orders, setOrders] = useState([]);
  const [confirmDialog, setConfirmDialog] = useState(false);
  const [orderId, setOrderId] = useState('');
  const [showPDF, setShowPDF] = useState(false);
  const [pdfDialog, setPdfDialog] = useState(false);

  const handleInvoice = () => {
    setShowPDF(true);
    setPdfDialog(!pdfDialog);
  };

  const fetchData = async () => {
    try {
      let apiUrl;
  if(role==="wholeseller"){
    apiUrl = `http://localhost:3001/orders/getWholeSellerOrderHistory/${user}`
  }
  else{
    apiUrl = `http://localhost:3001/orders/getUserOrderHistory/${user}`
  }
      const response = await fetch(apiUrl);
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      const data = await response.json();
      setOrders(data);
      // console.log(allProducts);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const deleteUser = async () => {
    try {
      let apiUrl;
      if(role==="wholeseller"){
        apiUrl = `http://localhost:3001/orders/orderDelivered/${orderId}`
      }
      else{
        apiUrl = `http://localhost:3001/orders/cancelOrder/${orderId}`
      }   
      const response = await fetch(apiUrl,{
        method: "POST",
        headers: {
          "Content-Type": "application/json", // Specify the content type if needed
        }
      });
      if (response === 200) {
        console.log("🚀 ~ deleteUser ~ response:", response)
        if(role==="wholeseller"){
          SuccessToaster("Status Updated")
        }else{
          SuccessToaster("Order Cancel")
        }
        
        fetchData();
      }
    } catch (error) {
      ErrorToaster(error)
    }
  }

  React.useEffect(() => {
    fetchData();
  }, []);

  return (
    <div style={{ height: 550, width: '100%' }}>
      {showPDF && <PdfDocument open={pdfDialog} onClose={() => setPdfDialog(false)} data={orders}/>}
      <ConfirmationDialog open={confirmDialog} onClose={() => setConfirmDialog(false)} action={deleteUser} role={role} />
    <TableContainer component={Paper}
    >
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell>order ID</TableCell>
            <TableCell align="right">Order BY</TableCell>
            <TableCell align="right">Profit</TableCell>
            <TableCell align="right">Customer Name</TableCell>
            <TableCell align="right">Phone Number</TableCell>
            <TableCell align="right">Order Status</TableCell>
            <TableCell align="right">Action</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {orders.map((row) => (
            <TableRow
              key={row?._id}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              <TableCell component="th" scope="row">{row?._id}</TableCell>
              <TableCell component="th" scope="row" align="right">{row?.orderedBy}</TableCell>
              <TableCell align="right">{row?.profit}</TableCell>
              <TableCell align="right">
                {row?.customerDetails?.name}
              </TableCell>
              <TableCell align="right">{row?.customerDetails?.phoneNumber}</TableCell>
              <TableCell align="right">{row?.status}</TableCell>
              <TableCell align="right">
                        <Box sx={{ display: "flex", alignItems: "center", justifyContent:"flex-end" }}>
                          {role==="wholeseller" ?(
                              <Tooltip title="Change Status">
                              <IconButton onClick={() => { setOrderId(row._id); setConfirmDialog(true) }}>
                                <ViewCozyTwoTone sx={{ fontSize: "20px", }} />
                              </IconButton>
                            </Tooltip>
                          ):(
                            <Tooltip title="Cancel Order">
                            <IconButton onClick={() => { setOrderId(row._id); setConfirmDialog(true) }}>
                              <CancelPresentation sx={{ fontSize: "20px", color:"#FF0000" }} />
                            </IconButton>
                          </Tooltip>
                          )}
                          <Tooltip title="Invoice">
                            <IconButton onClick={() => handleInvoice()}>
                              <AspectRatio color="secondary" sx={{ fontSize: "20px" }} />
                            </IconButton>
                          </Tooltip>
                        </Box>
                      </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  </div>
  )
}

export default Orders