import React, { useState } from "react";
import {
  Button,
  FormControl,
  Grid,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  Typography,
} from "@mui/material";
import { ErrorToaster, SuccessToaster } from "../components/Toaster";
import { useNavigate } from "react-router-dom";

const CreateProduct = () => {
  const navigate = useNavigate();
  const businessName = localStorage.getItem("businessName")

  const [productData, setProductData] = useState({
    item: "",
    price: "",
    quantity: "",
    description: "",
    storeName: businessName,
    image: null
  });

  const [categoryType, setCategoryType] = React.useState(null);

  const handleCategory = (event) => {
    setCategoryType(event.target.value);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setProductData({ ...productData, [name]: value });
  };

  const handleImageChange = (e) => {
    setProductData({ ...productData, image: e.target.files[0] });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const formDataToSend = new FormData();
      formDataToSend.append("item", productData.item);
      formDataToSend.append("category", categoryType);
      formDataToSend.append("price", productData.price);
      formDataToSend.append("quantity", productData.quantity);
      formDataToSend.append("description", productData.description);
      formDataToSend.append("storeName", productData.storeName);
      formDataToSend.append("image", productData.image);
      
      const response = await fetch("http://localhost:3001/products/addProduct",{
        method: "POST",
        body: formDataToSend,
      })
      if (response.ok) {
        // Handle success response
        console.log("Product created successfully");
        SuccessToaster("Product added")
        navigate('/wproducts')
      } else {
        const responeData = await response.json()
        console.log("🚀 ~ handleSubmit ~ responeData:", responeData)
        // Handle error response
        ErrorToaster("Make Sure Image is Uploaded")
        console.error("Failed to create product:", response);
      }
    } catch (error) {
      console.error("Error creating product:", error);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <Typography variant="h6">Create Product</Typography>
        </Grid>
        <Grid item xs={12} md={6} lg={6}>
          <TextField
            fullWidth
            required
            name="item"
            label="Item Name"
            value={productData.item}
            onChange={handleChange}
          />
        </Grid>
        <Grid item xs={12} md={6}  lg={6}>
        <FormControl fullWidth required>
              <InputLabel id="account-type-label">Category</InputLabel>
              <Select
              required
                labelId="account-type-label"
                id="account-type-select"
                value={categoryType}
                label="Category"
                onChange={handleCategory}
              >
                <MenuItem value="Laptop">Laptop</MenuItem>
                <MenuItem value="Peripherals">Peripherals</MenuItem>
                <MenuItem value="PC Parts">PC Parts</MenuItem>
                <MenuItem value="Gaming PC">Gaming PC</MenuItem>
              </Select>
            </FormControl>
          {/* Laptop, Peripherals, PC Parts, Gaming PC */}
        </Grid>
        <Grid item xs={12} md={6}  lg={6}>
          <TextField
            fullWidth
            required
            name="price"
            label="Price"
            type="number"
            value={productData.price}
            onChange={handleChange}
          />
        </Grid>
        <Grid item xs={12} md={6}  lg={6}>
          <TextField
            fullWidth
            required
            name="quantity"
            label="Quantity"
            type="number"
            value={productData.quantity}
            onChange={handleChange}
          />
        </Grid>
        <Grid item xs={12} md={6}  lg={6}>
          <TextField
            fullWidth
            required
            name="description"
            label="Description"
            multiline
            rows={4}
            value={productData.description}
            onChange={handleChange}
          />
        </Grid>
        <Grid item xs={12} md={6}  lg={6}>
          <TextField
          disabled
            fullWidth
            required
            name="storeName"
            label="Store Name"
            value={productData.storeName}
            onChange={handleChange}
          />
        </Grid>
        <Grid item xs={12} md={6}  lg={6}>
        <input
        type="file"
        accept="image/*"
        onChange={handleImageChange}
      />
        </Grid>
        <Grid item xs={12} sx={{ mt:4}}>
          <Button
            type="submit"
            variant="contained"
            color="primary"
          >
            Create
          </Button>
        </Grid>
      </Grid>
    </form>
  );
};

export default CreateProduct;
